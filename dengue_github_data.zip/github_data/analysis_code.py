"""S2 File. Analytic code for: Recorded laboratory confirmation in Ecuador's national dengue
surveillance data, 2021-2025. Input: MoH surveillance extract (OBSALUD open-data repository).
Requires: pandas, statsmodels, matplotlib. Usage: python S2_File_analysis_code.py <path_to_xlsx>"""
import sys, pandas as pd
from statsmodels.stats.proportion import proportion_confint
p = sys.argv[1]; raw = pd.read_csv(p) if p.endswith(".csv") else pd.read_excel(p)
# Exclusion: records assigned to epidemiological weeks > 36 of 2025 (post-date extraction)
df = raw[~((raw['Año'] == 2025) & (raw['Semana'] > 36))].copy()
df['grp'] = df['Institucion'].where(df['Institucion'].isin(['MSP', 'IESS']), 'Other providers')
def wilson(k, n):
    lo, hi = proportion_confint(k, n, method='wilson'); return round(lo*100, 1), round(hi*100, 1)
def summarise(d):
    a91 = d[d['Evento'] == 'A91X']; n = len(a91)
    conf = int(a91['Confirmado_laboratorio'].sum()); pcr = int((a91['Tipo_prueba'] == 1).sum())
    out = dict(records=len(d), cases=int(d['Total_casos'].sum()), A90_cases=int(d.loc[d['Evento']=='A90X','Total_casos'].sum()),
               A91=n, conf=conf, pcr=pcr, other=int((a91['Tipo_prueba'] == 2).sum()))
    if n:
        out['pct_conf'] = round(conf/n*100, 1); out['ci_conf'] = wilson(conf, n)
        out['pct_pcr_of_A91'] = round(pcr/n*100, 1); out['ci_pcr_of_A91'] = wilson(pcr, n)
    if conf:
        out['pct_pcr_of_conf'] = round(pcr/conf*100, 1); out['ci_pcr_of_conf'] = wilson(pcr, conf)
    return out
print('Excluded records:', len(raw) - len(df))
print('OVERALL', summarise(df))
for y, d in df.groupby('Año'): print('YEAR', y, summarise(d))
for g, d in df.groupby('grp'): print('INSTITUTION', g, summarise(d))
for p, d in df.groupby('Provincia'): print('PROVINCE', p, summarise(d))
# Identical A91 rows (no unique identifier in the extract)
a91 = df[df['Evento'] == 'A91X']; print('Identical A91 rows:', int(a91.duplicated(keep=False).sum()), 'of', len(a91))
# Weekly series used for Fig 1
weekly = df.groupby(['Año', 'Semana']).apply(lambda d: pd.Series({'cases': d['Total_casos'].sum(), 'A91': (d['Evento']=='A91X').sum(),
          'conf': d['Confirmado_laboratorio'].sum(), 'pcr': (d['Tipo_prueba']==1).sum()}), include_groups=False)
weekly.to_csv('weekly_series.csv')
